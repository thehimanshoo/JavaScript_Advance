console.log('Welcome to the JavaScript');

// To show the various messageg on the console window like some kind of log,info,warn,error & table messageg then we use this command

// log
console.log('I am a log message');

//info
console.info('I am an Info message');

//warn
console.warn('I am a warn message');

//error
console.error('I am an error message');

//table
let student = {
    Name : 'Ranjan',
    Age : 24,
    Cource : 'CSE',
    Department : 'UIC'
};
console.table(student);
//Display date on the console

// Display date on the web page using DOM